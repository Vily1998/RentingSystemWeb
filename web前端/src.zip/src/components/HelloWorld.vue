<template>
<html>
<head>
<title>Home</title>
	</head>
<body class="homepage">
			<div id="header">
				<div v-if="unLogon">
				<div id="input">
				<el-input v-model="account" placeholder="请输入账户" type="text" auto-complete="off"></el-input>
				</div>
				<div id="input1">
				<el-input v-model="password" placeholder="请输入密码" type="password" auto-complete="off"></el-input>	
				</div>
				<div id="logon">
				<el-button type="success" @click.native.prevent="handleSubmit">登录</el-button>
				</div>
				</div>
				<div v-else id="welcome">
					<!--p>欢迎回来！{{ account }}</p-->
					<el-alert
					:title = "'欢迎回来! ' + account"
					type="success"
					:closable="false">
					</el-alert>
				</div>
				
				<div id="register" v-if="unLogon">
					<!--<router-link to = "/register"><el-button type="text">注册</el-button></router-link>-->
					<!--el-button type="text" @click="dialogFormVisible = true">注册</el-button-->
					<el-button type="success" slot="reference" @click.native="changelink('/register')">注册</el-button>
					
				</div>
				<div v-else id="logout">
					<el-button type="danger" @click="logoff">注销</el-button>
				</div>
				<br><br><br><br><br><br>
				<!--div class="container"-->
					<!-- Logo -->
						<h1><a id="logo">海量新房源，省心上贝壳</a></h1>
					<!-- Nav -->
				<br><br><br><br>
				<el-row>
					<el-col :span="2" v-bind:offset="9" v-if="unLogon == false"><router-link to = "/user_information" >个人信息</router-link></el-col>
				<el-col :span="2"  v-if="unLogon == false"><router-link to = "/house_manage" >发布房源</router-link></el-col>
				<el-col :span="2" v-if="IsAdmin == true">
									<el-dropdown>
										<span class="el-dropdown-link">管理<i class="el-icon-arrow-down el-icon--right"></i>
										</span>
										<el-dropdown-menu slot="dropdown">
										<el-dropdown-item  @click.native="changelink('/user_manage')">用户管理</el-dropdown-item>
											<el-dropdown-item  @click.native="changelink('/manage2')">房源信息</el-dropdown-item>
											<el-dropdown-item  @click.native="changelink('/manage3')">需求信息</el-dropdown-item>
											<el-dropdown-item  @click.native="changelink('/income')">收入情况</el-dropdown-item>
										</el-dropdown-menu>
									</el-dropdown></el-col>
				</el-row>
					<!-- Banner -->
						<div id="banner">
							<div class="container">
								<section v-if="unLogon == false">
									<a class="button alt" @click="changelink('/calendar')">立即租房</a>
								</section>
								<br><br><br><br>
								<section v-if="unLogon == true">
									<br><br><br>
								</section>
							</div>
						</div>
				</div>
			<!--/div-->

		<!-- Featured -->
		<div id="feature">
			<h1>精挑细选，品质保障</h1>
		
			<el-carousel :interval="4000" type="card" height="600px">
    <el-carousel-item v-for="item in 4" :key="item">
      <h3>{{ item }}</h3>
    </el-carousel-item>
  </el-carousel>
  </div>

					<!-- Copyright -->
						<div class="copyright">
							Design: <a href="http://templated.co">BUPTcaipiao</a> Images: <a href="http://unsplash.com">BUPT</a> (<a href="http://unsplash.com/cc0"></a>)
						</div>


	</body>
</html>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
		unLogon:true,
		IsAdmin:false,
	  msg: 'Welcome to Your Vue.js App',
	  password: '',
		account: '',
		result:[],
    visible2: false,
        dialogTableVisible: false,
        dialogFormVisible: false,
        form: {
          name: '',
          idcard: '',
          password: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px'
    }
  },
  methods: {
    changelink(route){
            this.$router.replace(route);
        },
	  handleSubmit() {
		  if(this.password=='' || this.account=='')
		  {
			this.$notify.error({
            title: '错误',
            message:'账户名或密码不能为空',
            offset:50
            });
		  }
		  else if(this.account=="admin" && this.password=="123456")
		  {
							this.$notify({
								title: '成功',
								message:'欢迎回来，尊敬的 '+this.account,
								type: 'success',
								offset:50,
								});
								this.IsAdmin=true;
								this.unLogon= false;
							var myarray = new Array(3);
							myarray[0] = "admin";
							myarray[1] = "123456";
							myarray[2] = 0;
								this.$store.commit('change',myarray);
		  }
		  else{
			  this.$axios({
				method:"get",
				url:"http://localhost:8080/RentHouseSystem/user/CheckUser",
				params:{
					user_name:this.account
				}
			}).then((res)=>
			{
				let Isexist=res.data;
					console.log(Isexist);
					if(!Isexist)
					{
								this.$notify.error({
								title: '错误',
								message:'账户不存在',
								offset: 50
								})
					}
					if(Isexist)
					{
				this.$axios({
				method:"get",
				url:"http://localhost:8080/RentHouseSystem/user/CheckPassword",
				params:{
					user_name:this.account,
					password:this.password
				}
			}).then((res)=>
			{		let Isexist=res.data;
					console.log(Isexist);
					if(!Isexist)
					{
					this.$notify.error({
					title: '错误',
					message:'密码错误',
					offset: 50
					});
					}
					else
					{

							var myarray = new Array(4);
							myarray[0] = this.account;
							myarray[1] = this.password;
							//console.log(myarray);
							this.$store.commit('change',myarray);
							//console.log(this.$store.state);
							this.$notify({
								title: '成功',
								message:'欢迎回来，尊敬的 '+this.account,
								type: 'success',
								offset:50,
								
								});
								this.unLogon= false;
								this.IsAdmin= false;
					}
					
					


		})
					}
			})


			
		  }
		 
	  },
	  registersure() {
			this.visible2 = false;
			if(this.form.name=='' || this.form.id==''|| this.form.password =='')
		  {
			this.$notify.error({
            title: '错误',
            message:'账户名、身份证号和密码均不能为空',
            offset: 50
            });
		  }
		  else{
				//console.log(this.form);
			this.$axios({
				method:"post",
				url:"/api/user/add",
				data:{
					user_id:this.form.name,
					idcard:this.form.idcard,
					password:this.form.password,
					balance:10000.1
				}
			}).then((res)=>
			{
				console.log(res);
				if(res.data.errno == undefined)
				{
					this.$notify({
						title: '成功',
						message:'注册成功',
						type: 'success',
						offset: 50,
								
					});
					
				}
				else{
					this.$notify.error({
					title: '错误',
					message:'此账户已被注册',
					offset: 50
            		});
				}

		})
			
		  }
  },logoff() {
			this.unLogon = true;
			this.IsAdmin =false;
			var myarray = new Array(4);
			myarray[0] = '0';
			myarray[1] = '0';
			myarray[2] = '';
			myarray[3] = 0;
			this.$store.commit('change',myarray);
			this.$notify({
								title: '成功',
								message:'您已成功注销！',
								type: 'success',
								offset: 50,
								
								});
		},
		check() {
			if(this.$store.state.account != '0')
			{
				this.unLogon = false;
				this.account = this.$store.state.account;
			}
			if(this.$store.state.account == "admin")
			{
				this.unLogon = false;
				this.IsAdmin = true;
				this.account = this.$store.state.account;
			}

		},
		
	},
	mounted(){
			this.check()
		}
}

</script>

<style >
@import '../../static/style.css';
@import 'element-ui/lib/theme-chalk/index.css';
.el-dropdown-link {
    cursor: pointer;
	color: #FFF;
	text-decoration: none;
	font-size: 21px;

}
.el-col {
	text-decoration: none;
	font-size: 21px;
}
a {

	color: #FFF;
	text-decoration: none;
}
hover a {
	color: #fff;
}
.el-icon-arrow-down {
	font-size: 18px;
}
#input{
	position : absolute;
	right:330px;
	top:5px;
	color:black;
}
#input1{
	position : absolute;
	right:140px;
	top:5px;
	color:black;
}
#logon{
	position : absolute;
	right:60px;
	top:5px
}
#register{
	position : absolute;
	right:0px;
	top:5px;
}
#welcome{
	position : absolute;
	right:90px;
	top:2px;
}
#logout{
	position : absolute;
	right:10px;
	top:5px;
}
#feature{
	text-align: center;
	color:white;
}
.el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
		margin: 0;
  }
  
  .el-carousel__item:nth-child(6n) {
		background-color: #99a9bf;
		background: url("../assets/pic01.jpg") no-repeat;
		background-size: cover;
  }
  
	.el-carousel__item:nth-child(6n+3) {
		background-color: #d3dce6;
		background: url("../assets/pic02.jpg") no-repeat;
		background-size: cover;
	}
	.el-carousel__item:nth-child(6n+4) {
		background-color: #d3dce6;
		background: url("../assets/pic03.jpg") no-repeat;
		background-size: cover;
	}
	.el-carousel__item:nth-child(6n+5) {
		background-color: #d3dce6;
		background: url("../assets/pic04.jpg") no-repeat;
		background-size: cover;
  }
	  .copyright {
	  text-align: center;
  }

</style>
