<template>
<div style="background:white;">
	<div class="row mt-3" >
		<div class="col-md-12 col-lg-12">
      
        <el-col >
      <div>
        <router-link to = "/"><el-button><i class="el-icon-caret-left"></i> </el-button></router-link>
      </div>
  </el-col>
			<div class="card">
				<div class="card-body" >
					<form @submit.prevent="onSubmit" class="body">

						<div class="form-group">
							<label  >用户名</label>
               <p>{{salename}}</p>
						</div>

						<div class="form-group">
							<label for="st" >旧密码</label>
							<input class="form-control" 
							:class="{ 'is-valid':Issuccess,'is-invalid':Isdanger}"
							@blur="checkoldPassWord" 
							v-model="old_password" 
							placeholder="请输入密码" 
							type="password" id="st" style="width:800px;position:aboslute;	left:100px;">
							
					        
							<label class="alert alert-warning" v-if="nIsEmpty" for="password" style="color:red">{{ nAlert }}</label>
						</div>
						<div class="form-group">
							<label for="ps">新密码</label>
							<input class="form-control" 
							@blur="checkPassWord" 
							v-model="password" 
							placeholder="请输密码" 
							type="password" id="ps" style="width:800px;position:aboslute;	left:7px;">
							<label class="alert alert-warning" v-if="psIsEmpty" for="password" style="color:red">{{ psAlert }}</label>
						</div>
						<div class="form-group">
							<label for="nps">确认密码</label>
							<input class="form-control" 
							@blur="checkEnterPassWord" 
							v-model="enterpassword" 
							placeholder="请输密码" 
							type="password" id="nps" style="width:800px;position:aboslute;	left:7px;">
							<label class="alert alert-warning" v-if="epsIsEmpty" for="password" style="color:red">{{ epsAlert }}</label>
						</div>
            	<div class="form-group">
							<label for="nps">姓名</label>
               <p>{{name}}</p>
						</div>
            	<div class="form-group">
							<label for="nps">证件号</label>
               <p>{{certificate_num}}</p>
						</div>
              <div class="form-group">
							<label for="nps">手机号</label>
							<input class="form-control" 
							@blur="checknum" 
							v-model="mobile_num" 
							placeholder="请输手机号" 
							type="text" id="nps" style="width:800px;position:aboslute;	left:7px;">
							<label class="alert alert-warning" v-if="numIsEmpty" for="password" style="color:red">{{ numAlert }}</label>
						</div>
            <div>
              <label for="nps">城市</label>
              <p>{{register_city}}</p>
            </div>

						<button type="submit" class="btn btn-block btn-success">修改</button>
					</form> 
				</div>
			</div>
		</div>
	</div>
</div>
</template>
<script>


	export default{
		data(){
			return {
         options: [{
          value: '北京',
          label: '北京'
        }, {
          value: '上海',
          label: '上海'
        }, {
          value: '广州',
          label: '广州'
        }, {
          value: '深圳',
          label: '深圳'
        }, {
          value: '德州',
          label: '德州'
        }],
        value: '',
      
        salename:'',
        old_password_r:'',
        old_password:'',
				password:'',
				enterpassword:'',
				name:'',
				certificate_num:'',
				mobile_num:'',
				register_city:'',
				nIsEmpty:false,
				psIsEmpty:false,
        epsIsEmpty:false,
        numIsEmpty:false,
        nAlert:'密码不能为空哦',
        eAlert:'旧密码不正确',
				psAlert:'密码不能为空哦',
        epsAlert:'密码不能为空哦',
        numAlert:'电话号不能为空哦',
				Issuccess:false,
				Isdanger:false,
				classSelect:'',
				altermsg:''
			}
		},
		methods:{
			getNowFormatDate () {
  var date = new Date();
  var seperator1 = "-";
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var strDate = date.getDate();
   var strhours = date.getHours();
    var strminutes = date.getMinutes();
  if (month >= 1 && month <= 9) {
    month = "0" + month;
  }
  if (strDate >= 0 && strDate <= 9) {
    strDate = "0" + strDate;
  }
   if (strhours >= 1 && strhours <= 9) {
    strhours = "0" + strhours;
  }
  if (strminutes >= 0 && strminutes <= 9) {
    strminutes = "0" + strminutes;
  }
  var currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + strhours +':'+ strminutes;
  return currentdate;
},
      getInformation(){

				this.salename = this.$store.state.account;
			
          let params = new URLSearchParams();
          params.append('user_name', this.salename);

          	this.$axios({                
						method:"post",                           
					url:'http://localhost:8080/RentHouseSystem/user/UserInformation',               
					 data:params,                            
					 }).then(res=> {
             console.log(res);
             this.name=res.data.real_name;
             this.old_password_r=res.data.password;
             this.certificate_num=res.data.certificate_num;
             this.mobile_num=res.data.mobile_num;
             this.register_city=res.data.register_city;
              

           })

      },
			onSubmit(){
        if (this.old_password!=this.old_password_r) {
          this.$message({message: '旧密码有误！',type: 'warning'});
          }else{
          
				let params = new URLSearchParams();
				params.append('user_name', this.salename);
				params.append('new_password', this.password);
				params.append('new_mobile_num', this.mobile_num);
				if (this.password===this.enterpassword&&this.password!=''&&this.enterpassword!=''&&this.mobile_num!='') {
					this.$axios({                
						method:"post",                           
					url:'http://localhost:8080/RentHouseSystem/user/UpdateUser',               
					 data:params,                            
					 }).then(res=> {
						let resultjson=res.data;
						console.log(resultjson);
						if (resultjson==1) {
							this.$message({message: '修改成功',type: 'success'});
							//window.alert('注册成功,赶快登陆吧！');
							
						}else if(resultjson==0){
							//this.$message({message: '注册失败！',type: 'success'});
							this.$message.error('密码相似');
							//window.alert('注册失败,服务器错误,请重试！');
						}
					})
				}else if (this.password!=this.enterpassword) {
					this.$message({message: '两次密码不一样哦,请重新确认密码！',type: 'warning'});
					//window.alert('两次密码不一样哦,请重新确认密码');
				}else{
					this.$message({message: '表单数据不合法,请修正后再提交！',type: 'warning'});
					//window.alert('表单数据不合法,请修正后再提交');
				}
          
           }
          },
      			checkoldPassWord(){
				this.nIsEmpty=this.old_password===''?true:false;
				
			},
		
			checkPassWord(){
				this.psIsEmpty=this.password===''?true:false;
				
      },
      			checknum(){
				this.numIsEmpty=this.mobile_num===''?true:false;
				
			},
			checkEnterPassWord(){
				if (this.enterpassword!=''&&this.enterpassword===this.password) {
					this.epsIsEmpty=false;
				}else{
					this.epsAlert=this.enterpassword!=this.password?'两次密码不一样哦':'密码不能为空哦';
					this.epsIsEmpty=true;
				}
			}
    },
    	mounted(){
			this.getInformation()
		}
	}

</script>
<style scoped>
  body {
  background: #FFFFFF;
  }
</style>