<template>
<html>
<el-row>
  <el-col >
      <div>
        <router-link to = "/mydemand"><el-button><i class="el-icon-caret-left"></i> </el-button></router-link>
      </div>
  </el-col>
  <br><br>
  <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello}}</p>
      </el-col>
    <el-radio-group v-model="radio3"  >
      <el-radio-button label="东城"></el-radio-button>
      <el-radio-button label="西城"></el-radio-button>
      <el-radio-button label="海淀"></el-radio-button>
      <el-radio-button label="丰台"></el-radio-button>
      <el-radio-button label="朝阳"></el-radio-button>
      <el-radio-button label="昌平"></el-radio-button>
      <el-radio-button label="大兴"></el-radio-button>
    </el-radio-group>
  </div>
  </el-row>
</el-row>
 <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello2}}</p>
      </el-col>
      <el-col :span="2">
<el-input v-model="input" placeholder="请输入具体位置"></el-input>
</el-col>
  </div>
  </el-row>
  <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello3}}</p>
      </el-col>
      <el-col :span="2" >
<el-input v-model="input" style="width:120px;position:aboslute;	left:7px;"></el-input>
</el-col>
 <el-col :span="3" >
    <p>{{hello4}}</p>
    </el-col>
     <el-col :span="4" >
<el-input v-model="input" style="width:120px;position:aboslute;	left:-115px;"></el-input>
</el-col>
  </div>
  </el-row>
    <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello5}}</p>
      </el-col>
    <el-radio-group v-model="radio2" id='s1' >
      <el-radio :label="3">一居</el-radio>
      <el-radio :label="6">两居</el-radio>
      <el-radio :label="9">三居</el-radio>
      <el-radio :label="12">四居+</el-radio>
    </el-radio-group>
  </div>
  </el-row>
     <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello6}}</p>
      </el-col>
    <el-radio-group v-model="radio2" id='s2' >
      <el-radio :label="3">是</el-radio>
      <el-radio :label="6">否</el-radio>
    </el-radio-group>
            	<div id="logon">
				<el-button type="primary" @click.native.prevent="handleSubmit">增加</el-button>
				</div>
  </div>
  </el-row>

  
</html>
</template>
<style scoped>
    .el-row{
        background:white
    }
    #logon{
	position : absolute;
	left:400px;
  top:30px;
  }
  #s1{
    	position : absolute;
	left:70px;
  top:20px;
  }
  #s2{
    	position : absolute;
	left:70px;
  top:35px;
  }
    
</style>
<script>
  export default {
    data() {
      return {
        tableData: [

        ],
        hello:'地区：',
        hello2:'街区：',
        hello3:'楼层：',
        hello4:'————',
        hello5:'房型：',
        hello6:'是否电梯：',
      }
    },
    methods: {
    check() {
      this.tableData = [];
			this.$axios({
				method:"post",
				url:"/api/match/get_today_match",
				data:{
					
				}
      }).then((res)=>
      {
        var i = 0;
        for(;i<res.data.length;i++)
        {
          var myarray = new Array();
          myarray = res.data[i];
          var bifen = myarray.home_score + ' : ' + myarray.guest_score;
          var status;
          if(myarray.result == 0)
          {
            status = '未开始';
          }
          else if((myarray.result == 1))
          {
            status = '已开始';
          }
          else{
            status = '已结束';
          }
          var able;
          if(myarray.bet_able == 0)
          {
            able = '未开盘';
          }
          else if(myarray.bet_able == 1){
            able = '已开盘';
          }
          else if(myarray.bet_able == 2)
          {
            able = '已封盘';
          }
          var temp = {
            gameid: myarray.match_id,
            status:status,
            home:myarray.home_team,
            bifen:bifen,
            away:myarray.guest_team,
            able:able
          }
          console.log(temp);
          
          this.tableData.push(temp);
          
        }
        console.log(this.tableData);
      })
		}
    },
    mounted:function(){
			this.check()
		}
  }
</script>