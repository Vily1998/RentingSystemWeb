<template>
<html>
<el-row>
  <el-col >
      <div>
        <router-link to = "/Calendar"><el-button><i class="el-icon-caret-left"></i> </el-button></router-link>
      </div>
  </el-col>
  <br><br>
  <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello}}</p>
      </el-col>
  <el-select v-model="value" placeholder="选择城市">
    <el-option
      v-for="item in options"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select>
  </div>
  </el-row>
</el-row>
 <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello2}}</p>
      </el-col>
      <el-col :span="2">
<el-input v-model="input" placeholder="请输入具体位置"></el-input>
</el-col>
  </div>
  </el-row>
 <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello3}}</p>
      </el-col>
      <el-col :span="2" >
<el-input v-model="input" style="width:120px;position:aboslute;	left:7px;"></el-input>
</el-col>
 <el-col :span="3" >
    <p>{{hello4}}</p>
    </el-col>
     <el-col :span="4" >
<el-input v-model="input" style="width:120px;position:aboslute;	left:-115px;"></el-input>
</el-col>
  </div>
  </el-row>
    <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello5}}</p>
      </el-col>
    <el-radio-group v-model="radio2" id='s1' >
      <el-radio :label="3">一居</el-radio>
      <el-radio :label="6">两居</el-radio>
      <el-radio :label="9">三居</el-radio>
      <el-radio :label="12">四居+</el-radio>
    </el-radio-group>
  </div>
  </el-row>
     <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello6}}</p>
      </el-col>
    <el-radio-group v-model="radio2" id='s2' >
      <el-radio :label="3">是</el-radio>
      <el-radio :label="6">否</el-radio>
    </el-radio-group>
            	<div id="logon">
				<el-button type="primary" @click.native.prevent="handleSubmit">增加</el-button>
				</div>
  </div>
  </el-row>
     <el-table
    :data="tableData"
    style="width: 100%"
    max-height="700">
    <el-table-column
      label="地区"
      align="left">
      <template slot-scope="scope">
        <i class="el-icon-time"></i>
        <span style="margin-left: 10px">{{ scope.row.gameid}}</span>
      </template>
    </el-table-column>
    <el-table-column
      label="详细地址"
      align="left">
      <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.status }}</span>
      </template>
    </el-table-column>
    <el-table-column
      label="房型"
      align="left">
      <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.status }}</span>
      </template>
    </el-table-column>
    <el-table-column label="是否有电梯" align="left">
      <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.home }}</span>
      </template>
    </el-table-column>
    <el-table-column label="楼层" align="left">
        <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.bifen }}</span>
      </template>
        </el-table-column>
    <el-table-column label="价格" align="left">
        <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.away }}</span>
      </template>
        </el-table-column>
    <el-table-column label="规格" align="left">
        <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.able }}</span>
      </template>
        </el-table-column>
  </el-table>
  
</html>
</template>
<style scoped>
    .el-row{
        background:white
    }
    #logon{
	position : absolute;
	left:400px;
  top:30px;
  }
  #s1{
    	position : absolute;
	left:70px;
  top:20px;
  }
  #s2{
    	position : absolute;
	left:70px;
  top:35px;
  }
    
</style>
<script>
  export default {
    data() {
      return {
        
        options: [{
          value: '选项1',
          label: '北京'
        }, {
          value: '选项2',
          label: '上海'
        }, {
          value: '选项3',
          label: '广州'
        }, {
          value: '选项4',
          label: '深圳'
        }, {
          value: '选项5',
          label: '德州'
        }],
        value: '',
      

        tableData: [

        ],
        hello:'城市：',
        hello2:'街区：',
        hello3:'楼层：',
        hello4:'————',
        hello5:'房型：',
        hello6:'是否电梯：',
        city:'选择城市'
      }
    },
    methods: {
    check() {
      this.tableData = [];
			this.$axios({
				method:"post",
				url:"/api/match/get_today_match",
				data:{
					
				}
      }).then((res)=>
      {
        var i = 0;
        for(;i<res.data.length;i++)
        {
          var myarray = new Array();
          myarray = res.data[i];
          var bifen = myarray.home_score + ' : ' + myarray.guest_score;
          var status;
          if(myarray.result == 0)
          {
            status = '未开始';
          }
          else if((myarray.result == 1))
          {
            status = '已开始';
          }
          else{
            status = '已结束';
          }
          var able;
          if(myarray.bet_able == 0)
          {
            able = '未开盘';
          }
          else if(myarray.bet_able == 1){
            able = '已开盘';
          }
          else if(myarray.bet_able == 2)
          {
            able = '已封盘';
          }
          var temp = {
            gameid: myarray.match_id,
            status:status,
            home:myarray.home_team,
            bifen:bifen,
            away:myarray.guest_team,
            able:able
          }
          console.log(temp);
          
          this.tableData.push(temp);
          
        }
        console.log(this.tableData);
      })
		}
    },
    mounted:function(){
			this.check()
		}
  }
</script>