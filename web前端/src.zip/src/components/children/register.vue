<template>
<div style="background:white;">
	<div class="row mt-3" >
		<div class="col-md-12 col-lg-12">
      
        <el-col >
      <div>
        <router-link to = "/"><el-button><i class="el-icon-caret-left"></i> </el-button></router-link>
      </div>
  </el-col>
			<div class="card">
				<div class="card-body" >
					<form @submit.prevent="onSubmit" class="body">

						<div class="form-group">
							<label for="sn" >用户名</label>
							<input class="form-control" 
							:class="{ 'is-valid':Issuccess,'is-invalid':Isdanger}"
							@blur="checkSaleName" 
							v-model="salename" 
							placeholder="请输入用户名" 
							type="text" id="sn" style="width:800px;position:aboslute;	left:100px;">
							
							<div :class="[ classSelect ]" v-show="Isdanger||Issuccess" >
								{{ altermsg }}
							</div>
					        
							<label class="alert alert-warning" v-if="nIsEmpty" for="password" style="color:red">{{ nAlert }}</label>
						</div>

						<div class="form-group">
							<label for="ps">密码</label>
							<input class="form-control" 
							@blur="checkPassWord" 
							v-model="password" 
							placeholder="请输密码" 
							type="password" id="ps" style="width:800px;position:aboslute;	left:7px;">
							<label class="alert alert-warning" v-if="psIsEmpty" for="password" style="color:red">{{ psAlert }}</label>
						</div>

						<div class="form-group">
							<label for="nps">确认密码</label>
							<input class="form-control" 
							@blur="checkEnterPassWord" 
							v-model="enterpassword" 
							placeholder="请输密码" 
							type="password" id="nps" style="width:800px;position:aboslute;	left:7px;">
							<label class="alert alert-warning" v-if="epsIsEmpty" for="password" style="color:red">{{ epsAlert }}</label>
						</div>
            	<div class="form-group">
							<label for="nps">姓名</label>
							<input class="form-control" 
							@blur="checkname" 
							v-model="name" 
							placeholder="请输姓名" 
							type="text" id="nps" style="width:800px;position:aboslute;	left:7px;">
							<label class="alert alert-warning" v-if="nameIsEmpty" for="password" style="color:red">{{ nameAlert }}</label>
						</div>
            	<div class="form-group">
							<label for="nps">证件号</label>
							<input class="form-control" 
							@blur="checkcnum" 
							v-model="certificate_num" 
							placeholder="请输证件号" 
							type="text" id="nps" style="width:800px;position:aboslute;	left:7px;">
							<label class="alert alert-warning" v-if="cnumIsEmpty" for="password" style="color:red">{{ cnumAlert }}</label>
						</div>
            						<div class="form-group">
							<label for="nps">手机号</label>
							<input class="form-control" 
							@blur="checkmnum" 
							v-model="mobile_num" 
							placeholder="请输手机号" 
							type="text" id="nps" style="width:800px;position:aboslute;	left:7px;">
							<label class="alert alert-warning" v-if="mnumIsEmpty" for="password" style="color:red">{{ mnumAlert }}</label>
						</div>
            <div>
              <label for="nps">城市</label>
              <el-select v-model="register_city" placeholder="选择城市">
              <el-option
                 v-for="item in options"
                    :key="item.value"
               :label="item.label"
                 :value="item.value">
                     </el-option>
               </el-select>
            </div>

						<button type="submit" class="btn btn-block btn-success">注册</button>
					</form> 
				</div>
			</div>
		</div>
	</div>
</div>
</template>
<script>


	export default{
		data(){
			return {
         options: [{
          value: '北京',
          label: '北京'
        }, {
          value: '上海',
          label: '上海'
        }, {
          value: '广州',
          label: '广州'
        }, {
          value: '深圳',
          label: '深圳'
        }, {
          value: '德州',
          label: '德州'
        }],
        value: '',
      
				salename:'',
				password:'',
				enterpassword:'',
				name:'',
				certificate_num:'',
				mobile_num:'',
				register_city:'',
				nIsEmpty:false,
				psIsEmpty:false,
				epsIsEmpty:false,
				nameIsEmpty:false,
				cnumIsEmpty:false,
				mnumIsEmpty:false,
				nAlert:'账号不能为空哦',
				psAlert:'密码不能为空哦',
				epsAlert:'密码不能为空哦',
				nameAlert:'姓名不能为空哦',
				cnumAlert:'证件号不能为空哦',
				mnumAlert:'电话不能为空哦',
				Issuccess:false,
				Isdanger:false,
				classSelect:'',
				altermsg:''
			}
		},
		methods:{
			getNowFormatDate () {
  var date = new Date();
  var seperator1 = "-";
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var strDate = date.getDate();
   var strhours = date.getHours();
    var strminutes = date.getMinutes();
  if (month >= 1 && month <= 9) {
    month = "0" + month;
  }
  if (strDate >= 0 && strDate <= 9) {
    strDate = "0" + strDate;
  }
   if (strhours >= 1 && strhours <= 9) {
    strhours = "0" + strhours;
  }
  if (strminutes >= 0 && strminutes <= 9) {
    strminutes = "0" + strminutes;
  }
  var currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + strhours +':'+ strminutes;
  return currentdate;
},
			onSubmit(){
				let params = new URLSearchParams();
				params.append('user_name', this.salename);
				params.append('password', this.password);
				params.append('user_type', 1);
				params.append('real_name', this.name);
				params.append('certificate_num', this.certificate_num);
				params.append('certificate_type', 0);
				params.append('user_level', 0);
				params.append('register_time', this.$options.methods.getNowFormatDate());
				params.append('modify_time', this.$options.methods.getNowFormatDate());
				params.append('mobile_num', this.mobile_num);
				params.append('register_city', this.register_city);
				if (this.password===this.enterpassword&&this.Issuccess&&this.password!=''&&this.enterpassword!='') {
					this.$axios({                
						method:"post",                           
					url:'http://localhost:8080/RentHouseSystem/user/AddUser',               
					 data:params,                            
					 }).then(res=> {
						let resultjson=res.data;
						console.log(resultjson);
						if (resultjson.code!=0) {
							this.salename='';
							this.password='';
							this.nIsEmpty=false;
							this.psIsEmpty=false;
							this.Issuccess=false;
							this.Isdanger=false;
							this.$message({message: '注册成功,赶快登陆吧！',type: 'success'});
							//window.alert('注册成功,赶快登陆吧！');
							
						}else{
							//this.$message({message: '注册失败！',type: 'success'});
							this.$message.error('注册失败,网络异常！');
							//window.alert('注册失败,服务器错误,请重试！');
						}
					})
				}else if (this.password!=this.enterpassword) {
					this.$message({message: '两次密码不一样哦,请重新确认密码！',type: 'warning'});
					//window.alert('两次密码不一样哦,请重新确认密码');
				}else{
					this.$message({message: '表单数据不合法,请修正后再提交！',type: 'warning'});
					//window.alert('表单数据不合法,请修正后再提交');
				}
			},
			checkSaleName(){
				this.nIsEmpty=this.salename===''?true:false;
					  this.$axios({
				method:"get",
				url:"http://localhost:8080/RentHouseSystem/user/CheckUser",
				params:{
					user_name:this.salename
				}
					}).then(res=> {
					let Isexist=res.data;
					console.log(Isexist);
					if(this.nIsEmpty){
						console.log("走名字为空");
						this.classSelect='invalid-feedback';
						this.Issuccess=false;
						this.Isdanger=false;
					}else {
						
						if(Isexist){
							
							this.Issuccess=false;
							this.Isdanger=true;
							this.classSelect='invalid-feedback';
							console.log("名字不为空   账号已存在"+this.Issuccess,this.Isdanger);
							this.altermsg="这个是本网站的老用户了哦，快输入密码登录吧";
						}else if(!Isexist){
							
							this.Issuccess=true;
							this.Isdanger=false;
							this.classSelect='valid-feedback';
							console.log("名字不为空   账号不存在"+this.Issuccess,this.Isdanger);
							this.altermsg="你输入的账号可能还不存在，赶快去注册吧";
						}
					}
				})
			},
			checkPassWord(){
				this.psIsEmpty=this.password===''?true:false;
				
			},
			checkname(){
				this.nameIsEmpty=this.name===''?true:false;
				
			},
			checkcnum(){
				this.cnumIsEmpty=this.certificate_num===''?true:false;
				
			},
			checkmnum(){
				this.mnumIsEmpty=this.mobile_num===''?true:false;
				
			},
			checkEnterPassWord(){
				if (this.enterpassword!=''&&this.enterpassword===this.password) {
					this.epsIsEmpty=false;
				}else{
					this.epsAlert=this.enterpassword!=this.password?'两次密码不一样哦':'密码不能为空哦';
					this.epsIsEmpty=true;
				}
			}
		}
	}

</script>
<style scoped>
  body {
  background: #FFFFFF;
  }
</style>