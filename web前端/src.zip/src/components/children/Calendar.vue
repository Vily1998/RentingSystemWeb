<style scoped>
@import 'vue2-animate/dist/vue2-animate.min.css';
@import url("//unpkg.com/element-ui@2.4.4/lib/theme-chalk/index.css");
 * {
  box-sizing: border-box;
  }
   
  ul {
  list-style-type: none;
  }
  #input2{
	position : absolute;
	left:10px;
	top:87px
  }
#logon{
	position : absolute;
	left:200px;
  top:87px;
  }
  body {
  font-family: Verdana, sans-serif;
  background: #E8F0F3;
  }
  #calendar{
  width:80%;
  margin: 0 auto;
  box-shadow: 0 2px 2px 0 rgba(0,0,0,0.14), 0 3px 1px -2px rgba(0,0,0,0.1), 0 1px 5px 0 rgba(0,0,0,0.12);
  }
  .month {
  width: 100%;
  background: #00B8EC;
  }
   
  .month ul {
  margin: 0;
  padding: 0;
  display: flex;
  justify-content: space-between;
  }
   
  .year-month {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-around;
  }
   
  .year-month:hover {
  background: rgba(150, 2, 12, 0.1);
  }
   
  .choose-year {
  padding-left: 20px;
  padding-right: 20px;
  }
   
  .choose-month {
  text-align: center;
  font-size: 1.5rem;
  }
   
  .arrow {
  padding: 15px;
  }
   
  .arrow:hover {
  background: rgba(100, 2, 12, 0.1);
  }
   
  .month ul li {
  color: white;
  font-size: 20px;
  text-transform: uppercase;
  letter-spacing: 3px;
  }
   
  .weekdays {
  margin: 0;
  padding: 10px 0;
  background-color: #00B8EC;
  display: flex;
  flex-wrap: wrap;
  color: #FFFFFF;
  justify-content: space-around;
  }
   
  .weekdays li {
  display: inline-block;
  width: 13.6%;
  text-align: center;
  }
   
  .days {
  padding: 0;
  background: #FFFFFF;
  margin: 0;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  }
   
  .days li {
  list-style-type: none;
  display: inline-block;
  width: 14.2%;
  text-align: center;
  padding-bottom: 15px;
  padding-top: 15px;
  font-size: 1rem;
  color: #000;
  }
   
  .days li .active {
  padding: 6px 10px;
  border-radius: 50%;
  background: #00B8EC;
  color: #fff;
  }
   
  .days li .other-month {
  padding: 5px;
  color: gainsboro;
  }
   
  .days li:hover {
  background: #e1e1e1;
  }
  .el-carousel__item h3 {
    color: #475669;
    font-size: 18px;
    opacity: 0.75;
    line-height: 300px;
    margin: 0;
  }
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
  
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
</style>

<template>
  <div>
  <el-menu
  :default-active="activeIndex2"
  class="el-menu-demo"
  mode="horizontal"
  @select="handleSelect"
  background-color="#00B8EC"
  text-color="#fff"
  active-text-color="#ffd04b">
  <el-menu-item index="1" @click="changelink('/')">主页</el-menu-item>
<el-menu-item index="2"  @click="changelink('/reference')">需求参考</el-menu-item>
  <el-menu-item index="3"  @click="changelink('/mydemand')">我的需求</el-menu-item>
<el-menu-item index="4"  @click="changelink('/information')">详细需求租房</el-menu-item>
</el-menu>
<el-col :span="24"><div class="grid-content bg-purple-dark">
<el-card class="box-card" shadow="hover" body-style="height:500px">
    		<div id="input2">
				<el-input v-model="account" placeholder="输入区域名开始找房" type="text" auto-complete="off"></el-input>
				</div>
        	<div id="logon">
				<el-button type="success" @click.native.prevent="handleSubmit">确认</el-button>
				</div>
              <div slot="header" class="clearfix">
                        <br><br>        
      <span>已经为你搜索到以下房源</span>
    </div>
     <el-table
    :data="tableData"
    style="width: 100%"
    max-height="700">
    <el-table-column
      label="地区"
      align="left">
      <template slot-scope="scope">
        <i class="el-icon-time"></i>
        <span style="margin-left: 10px">{{ scope.row.gameid}}</span>
      </template>
    </el-table-column>
    <el-table-column
      label="详细地址"
      align="left">
      <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.status }}</span>
      </template>
    </el-table-column>
    <el-table-column
      label="房型"
      align="left">
      <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.status }}</span>
      </template>
    </el-table-column>
    <el-table-column label="是否有电梯" align="left">
      <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.home }}</span>
      </template>
    </el-table-column>
    <el-table-column label="楼层" align="left">
        <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.bifen }}</span>
      </template>
        </el-table-column>
    <el-table-column label="价格" align="left">
        <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.away }}</span>
      </template>
        </el-table-column>
    <el-table-column label="规格" align="left">
        <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.able }}</span>
      </template>
        </el-table-column>
  </el-table>
  </el-card>
  </div>
</el-col>
</div>
</template>

<script>
import loadJs from '../../assets/test.js'
import RemoteJs from '../../components/remotejs'// 导入组件
import util from '../../util'
export default
{
  name:'calendar',
  data() {
    return{
   currentDay: 1,
   currentMonth: 1,
   currentYear: 1970,
   currentWeek: 1,
   s_flag:1,
   f_flag:1,
   days: [],
   todayMatch:[],
   tableData: [],
   }
  },
  created: function() {
   this.initData(null);
  },
  props: {
    testid: {
     type: String,
     required: true
    }
   },
  mounted()
  {
    const s = document.createElement('script');
    s.type = 'text/javascript';
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/vue/1.0.18/vue.min.js';
    document.body.appendChild(s);
  },
  components:{
    RemoteJs
  },
  methods: {
  changelink(route){
    this.$router.replace(route);
  },
  getmatchinfo(info){
    this.$axios({
      method:"post",
      url:'/api/match/get_match', 
      data:{
        time:util.formatDate.format(new Date(info),'yyyy-MM-dd')
      }
    }).then((res) => {
        console.log(res);
        this.todayMatch=[];
        for(var i=0;i<res.data.length;i++)
        {
          this.todayMatch.push(res.data[i]);
          this.todayMatch[i].time = util.formatDate.format(new Date(this.todayMatch[i].time),'yyyy-MM-dd hh:mm:ss');
        }
    })
  },
   initData: function(cur) {
   var date;
   if (cur) {
    date = new Date(cur);
   } else {
    date = new Date();
   }
   this.currentDay = date.getDate();
   this.currentYear = date.getFullYear();
   this.currentMonth = date.getMonth() + 1;
   this.currentWeek = date.getDay(); // 1...6,0
   if (this.currentWeek == 0) {
    this.currentWeek = 7;
   }
   var str = this.formatDate(this.currentYear , this.currentMonth, this.currentDay);
   console.log("today:" + str + "," + this.currentWeek);
   this.days.length = 0;
   // 今天是周日，放在第一行第7个位置，前面6个
   for (var i = this.currentWeek - 1; i >= 0; i--) {
    var d = new Date(str);
    d.setDate(d.getDate() - i);
    console.log("y:" + d.getDate());
    this.days.push(d);
   }
   for (var i = 1; i <= 35 - this.currentWeek; i++) {
    var d = new Date(str);
    d.setDate(d.getDate() + i);
    this.days.push(d);
   }
   },
   pick: function(date) {
   alert(this.formatDate( date.getFullYear() , date.getMonth() + 1, date.getDate()));
   },
   pickPre: function(year, month) {
   // setDate(0); 上月最后一天
   // setDate(-1); 上月倒数第二天
   // setDate(dx) 参数dx为 上月最后一天的前后dx天
   var d = new Date(this.formatDate(year , month , 1));
   d.setDate(0);
   this.initData(this.formatDate(d.getFullYear(),d.getMonth() + 1,1));
   },
   pickNext: function(year, month) {
   var d = new Date(this.formatDate(year , month , 1));
   d.setDate(35);
   this.initData(this.formatDate(d.getFullYear(),d.getMonth() + 1,1));
   },
   pickYear: function(year, month) {
   alert(year + "," + month);
   },
    
   // 返回 类似 2016-01-02 格式的字符串
   formatDate: function(year,month,day){
   var y = year;
   var m = month;
   if(m<10) m = "0" + m;
   var d = day;
   if(d<10) d = "0" + d;
   return y+"-"+m+"-"+d
   },
  },
  }
 </script>