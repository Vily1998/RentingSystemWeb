<template>
  <div>
      <div class="line"></div>
      <!--router-link @click.native="handleDelete('000',flag);addone()" :to="{path:this.$store.state.count}">{{this.$store.state.count}}</router-link-->
          <el-menu
            :default-active="activeIndex2"
            class="el-menu-demo"
            mode="horizontal"
            @select="handleSelect"
            background-color="#ff4000"
            text-color="#fff"
            active-text-color="#ffd04b">
            <el-menu-item index="1" @click="changelink('/')">主页</el-menu-item>
            <el-submenu index="2">
              <template slot="title">个人管理</template>
              <el-menu-item index="2-1" @click="changelink('/win_lose')">我的房源</el-menu-item>
              <el-menu-item index="2-2" @click="changelink('/goal')">租房申请</el-menu-item>
              <el-menu-item index="2-3" @click="changelink('/total')">租房需求</el-menu-item>
              <el-menu-item index="2-3" @click="changelink('/give_ball')">现有房源</el-menu-item>
            </el-submenu>
          </el-menu>
          <el-card class="box-card" shadow="hover" body-style="height:800px">
            <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello}}</p>
      </el-col>
    <el-radio-group v-model="radio3"  >
      <el-radio-button label="东城"></el-radio-button>
      <el-radio-button label="西城"></el-radio-button>
      <el-radio-button label="海淀"></el-radio-button>
      <el-radio-button label="丰台"></el-radio-button>
      <el-radio-button label="朝阳"></el-radio-button>
      <el-radio-button label="昌平"></el-radio-button>
      <el-radio-button label="大兴"></el-radio-button>
    </el-radio-group>
  </div>
  </el-row>
 <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello2}}</p>
      </el-col>
      <el-col :span="2">
<el-input v-model="input" placeholder="请输入具体位置"></el-input>
</el-col>
  </div>
  </el-row>
  <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello3}}</p>
      </el-col>
      <el-col :span="2" >
<el-input v-model="input" style="width:120px;position:aboslute;	left:7px;"></el-input>
</el-col>
  </div>
  </el-row>
    <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello5}}</p>
      </el-col>
    <el-radio-group v-model="radio2" id='s1' >
      <el-radio :label="3">一居</el-radio>
      <el-radio :label="6">两居</el-radio>
      <el-radio :label="9">三居</el-radio>
      <el-radio :label="12">四居+</el-radio>
    </el-radio-group>
  </div>
  </el-row>
     <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello6}}</p>
      </el-col>
    <el-radio-group v-model="radio2" id='s2' >
      <el-radio :label="3">是</el-radio>
      <el-radio :label="6">否</el-radio>
    </el-radio-group>
  </div>
  </el-row>
    <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello7}}</p>
      </el-col>
      <el-col :span="2" >
<el-input v-model="input" style="width:120px;position:aboslute;	left:7px;"></el-input>
</el-col>
  </div>
  </el-row>
    <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello8}}</p>
      </el-col>
      <el-col :span="2" >
<el-input v-model="input" style="width:120px;position:aboslute;	left:7px;"></el-input>
</el-col>
  </div>
  </el-row>
  <el-row>
    <el-col :span='1'>
       <p>{{hello9}}</p>
    </el-col>
    <el-col :span='2'>
  <el-upload
  action="https://jsonplaceholder.typicode.com/posts/"
  list-type="picture-card"
  :on-preview="handlePictureCardPreview"
  :on-remove="handleRemove"
  >
  <i class="el-icon-plus"></i>
</el-upload>
<el-dialog :visible.sync="dialogVisible">
  <img width="100%" :src="dialogImageUrl" alt="">
</el-dialog>
    </el-col>
  </el-row>
  <el-row>
  <div id="logons">
				<el-button type="primary" @click.native.prevent="handleSubmit">发布房源</el-button>
				</div>
  </el-row>
</el-card>
  </div>
  </template>
  
<script>
    export default {
      data() {
        return {
          use:1,
          tableData: [],
          flag :"calendar",
          sendData:[],
          lotteryData:[],
                  hello:'地区：',
        hello2:'街区：',
        hello3:'价格：',
        hello4:'————',
        hello5:'房型：',
        hello6:'是否电梯：',
        hello7:'楼层:',
        hello8:'规格:',
        hello9:'图片:',
                dialogImageUrl: '',
        dialogVisible: false
        }
      },
      methods: {
        
                changelink(route){
            this.$router.replace(route);
        },
      }
    }
  </script>

<style scoped>
      #logons{
	position : absolute;
	left:250px;
  top:30px;
  }
  .el-col {
	text-decoration: none;
	font-size: 15px;
}
</style>