import Home from './components/HelloWorld.vue'
import Calendar from './components/children/Calendar.vue'
import adddemand from './components/children/adddemand.vue'
import information from './components/children/information.vue'
import reference from './components/children/reference.vue'
import mydemand from './components/children/mydemand.vue'
import user_information from './components/user_information.vue'
import register from './components/children/register.vue'
import income from './components/children/income.vue'
import house_manage from './components/children/house_manage.vue'
import user_manage from './components/children/user_manage.vue'
const routers = 
[
  {
    path: '/',
    component: Home,
  },
  {
    path: '/home',
    name: 'home',
    component: Home,
  },
  {
    path: '/Calendar',
    name: 'calendar',
    component: Calendar,
  },

  {
    path: '/adddemand',
    name: 'adddemand',
    component: adddemand
  },
  {
    path: '/information',
    name: 'information',
    component: information
  },
  {
    path: '/reference',
    name: 'reference',
    component: reference,
  },
  {
    path: '/mydemand',
    name: 'mydemand',
    component: mydemand,
  },
  {
    path: '/register',
    name: 'register',
    component: register,
  },
  {
    path: '/user_information',
    name: 'user_information',
    component: user_information,
  },
  {
    path: '/income',
    name: 'income',
    component: income,
  },
  {
    path: '/house_manage',
    name: 'house_manage',
    component: house_manage,
  },
  {
    path: '/user_manage',
    name: 'user_manage',
    component: user_manage,
  },
]

export default routers
