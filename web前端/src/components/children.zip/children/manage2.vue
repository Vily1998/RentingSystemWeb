<template>
  <html>
    <head>
      <title>房源信息</title>
    </head>
    <body>
      <router-link to = "/"><el-button><i class="el-icon-caret-left"></i> </el-button></router-link>
      <router-link to = "myhouse"><el-button><i class="el-icon-caret-left"></i> </el-button></router-link>
      <br>
      <br>
      <span v-for="n in 10"><!这里可能有错误,不知道可不可以使用length代替这里的10>
        <el-container>
        <el-aside width="80px">
          
        </el-aside>
        <el-aside width="320px">
          <img src="../../assets/backh.jpg" height="200" width="264"/>
        </el-aside>
        <el-aside width="750px">
          <br>
          <br>
          <font size="5" color="orange"><!这里是tableData[i].description></font>
          <br>
          <font size="3" color="white"><br><!这里是tableData[i].house_type> &nbsp;&nbsp;&nbsp;<!这里是tableData[i].house_area></font>
          <br>
          <br>

        </el-aside>
        <el-main>
          <br><br><br><font size="5" color="orange"><!这里是tableData[i].house_rent_per_month></font>
        </el-main>
        </el-container>
      <br>
      </span>
      <div class="block">
        <el-pagination
        layout="prev, pager, next"
        :total="50">
        </el-pagination>
      </div>
    </body>
  </html>
</template>





<script>
  export default {
         data() {
      return {
        tableData:[],
        length:0,
      }
    },
    methods: {
      gethouse(){
        let params = new URLSearchParams();
                    params.append('user_id', this.$store.state.id);
					this.$axios({                
						method:"post",                           
					url:'http://localhost:8080/RentHouseSystem/house/SelectHouseByUserId',               
					 data:params,                            
					 }).then(res=> {
						length=res.data.length;
            var tempData=[];
        for(var k=0;k<res.data.length;k++)
        {
          tempData.push(res.data[k]);
        }
        console.log(tempData);
        for(var k=0;k<tempData.length;k++)
        {
          var temp={
            house_id:tempData[k].house_id,
            city_name:tempData[k].city_name,
            community_name:tempData[k].community_name,
            house_num:tempData[k].house_num,
            house_type:tempData[k].house_type,
            house_area:tempData[k].house_area,
            house_floor:tempData[k].house_floor,
            is_elevator:tempData[k].is_elevator,
            description:tempData[k].description,
            deposit:tempData[k].deposit,
            payment_method:tempData[k].payment_method,
            rent_per_month:tempData[k].rent_per_month,
            modify_time:tempData[k].modify_time,
            state:tempData[k].state
          }
          console.log(temp)
          if(temp.house_type==1)
          temp.house_type='一居';
          if(temp.house_type==2)
          temp.house_type='二居';
          if(temp.house_type==3)
          temp.house_type='三居';
          if(temp.house_type==4)
          temp.house_type='四居+';
          if(temp.is_elevator==1)
          temp.is_elevator='有';
          if(temp.is_elevator==0)
          temp.is_elevator='无';
          if(temp.payment_method==1)
          temp.payment_method='月';
          if(temp.payment_method==2)
          temp.payment_method='季';
          if(temp.payment_method==3)
          temp.payment_method='年';
                    if(temp.state==1)
          temp.state='已出租';
          if(temp.state==0)
          temp.state='未出租';

          this.tableData.push(temp);
        }
        console.log(this.tableData);
					})
			
  },
       

      photo(row){
        this.$router.push({
                    path:"/showphoto",//跳转路由
                    query:{//参数对象
                        house_id:row.house_id,
                    }

      })
      }
    },
        	mounted(){
			this.gethouse()
		}
  }
  
</script>
