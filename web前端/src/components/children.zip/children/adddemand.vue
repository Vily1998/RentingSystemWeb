<template>
<html>
<el-row>
  <el-col >
      <div>
        <router-link to = "/mydemand"><el-button><i class="el-icon-caret-left"></i> </el-button></router-link>
      </div>
  </el-col>
  <br><br>
</el-row>
          <el-card class="box-card" shadow="hover" body-style="height:860px" >
            <div class="card" >
              
				<div class="card-body" >
					<form @submit.prevent="onSubmit" class="body">
            
<el-row>
  <div >
    
    <el-col :span="1">
    <p>{{hello}}</p>
      </el-col>
    <el-select v-model="city_name" placeholder="选择城市">
    <el-option
      v-for="item in options"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select>
  </div>
  </el-row>
 <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello2}}</p>
      </el-col>
      <el-col :span="2">
<el-input v-model="community_name" placeholder="请输入具体位置" style="width:400px;position:aboslute;	"></el-input>
</el-col>
  </div>
  </el-row>

    <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello5}}</p>
      </el-col>
    <el-radio-group v-model="house_type" id='s1' >
      <el-radio :label="1">一居</el-radio>
      <el-radio :label="2">两居</el-radio>
      <el-radio :label="3">三居</el-radio>
      <el-radio :label="4">四居+</el-radio>
    </el-radio-group>
  </div>
  </el-row>
     <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello6}}</p>
      </el-col>
    <el-radio-group v-model="is_elevator" id='s2' >
      <el-radio :label="1">是</el-radio>
      <el-radio :label="0">否</el-radio>
    </el-radio-group>
  </div>
  </el-row>
    <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello7}}</p>
      </el-col>
      <el-col :span="2" >
<el-input v-model="house_floor" style="width:120px;position:aboslute;	"></el-input>
</el-col>
  </div>
  </el-row>
    <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello10}}</p>
      </el-col>
      <el-col :span="2" >
<el-input v-model="description" style="width:400px;position:aboslute;	"></el-input>
</el-col>
  </div>
  </el-row>
    <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello11}}</p>
      </el-col>
      <el-col :span="2" >
<el-input v-model="deposit"  placeholder="单位：月" style="width:150px;position:aboslute;	"></el-input>
</el-col>
  </div>
  </el-row>
       <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello12}}</p>
      </el-col>
    <el-radio-group v-model="payment_method" id='s3' >
      <el-radio :label="1">月</el-radio>
      <el-radio :label="2">季</el-radio>
       <el-radio :label="3">年</el-radio>
    </el-radio-group>
  </div>
  </el-row>
  <el-row>
  <div >
    <el-col :span="1">
    <p>{{hello13}}</p>
      </el-col>
      <el-col :span="2" >
<el-input v-model="rent_per_month"  placeholder="单位：元" style="width:150px;position:aboslute;	"></el-input>
</el-col>
  </div>
  </el-row>
  

						<button type="submit" class="btn btn-block btn-success">添加</button>
					</form> 
				</div>
			</div>
      <div>
    <img src="../../assets/backh.jpg" height="900" width="948" style="position:absolute; left:600px; top:69px; "/>
    </div>
</el-card>


  
</html>
</template>
<style scoped>
  #logons{
	position : absolute;
	left:250px;
  top:30px;
  }
  .el-col {
	text-decoration: none;
	font-size: 15px;
}
</style>
    
<script>
    export default {
      data() {
        return {
          options: [{
          value: '北京',
          label: '北京'
        }, {
          value: '上海',
          label: '上海'
        }, {
          value: '广州',
          label: '广州'
        }, {
          value: '深圳',
          label: '深圳'
        }, {
          value: '德州',
          label: '德州'
        }],
        value: '',
        house_id:0,
user_id:0,
city_name: '',
community_name: '',
house_num: '',
house_type: -1,
house_area: 0,
house_floor: '',
is_elevator: -1,
description: '',
deposit: '',
payment_method: -1,
rent_per_month: '',
register_time: '',
modify_time: '',
state: 0,
                  hello:'地区：',
        hello2:'街区：',
        hello4:'具体门楼号：',
        hello5:'房型：',
        hello6:'是否电梯：',
        hello7:'楼层:',
        hello8:'面积:',
        hello9:'图片:',
        hello10:'房屋家居描述：',
        hello11:'押金：',
        hello12:'租金支付方式：',
        hello13:'每月租金：',
        hello14:'状态：',
        dialogImageUrl: '',
        dialogVisible: false,
        }
      },
      methods:{
      getNowFormatDate () {
  var date = new Date();
  var seperator1 = "-";
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var strDate = date.getDate();
   var strhours = date.getHours();
    var strminutes = date.getMinutes();
  if (month >= 1 && month <= 9) {
    month = "0" + month;
  }
  if (strDate >= 0 && strDate <= 9) {
    strDate = "0" + strDate;
  }
   if (strhours >= 1 && strhours <= 9) {
    strhours = "0" + strhours;
  }
  if (strminutes >= 0 && strminutes <= 9) {
    strminutes = "0" + strminutes;
  }
  var currentdate = year + seperator1 + month + seperator1 + strDate + ' ' + strhours +':'+ strminutes;
  return currentdate;
},

        onSubmit(){
        let params = new URLSearchParams();
        this.user_id=this.$store.state.id;
        console.log(this.user_id);
				params.append('user_id', this.user_id);
				params.append('city_name', this.city_name);
				params.append('community_name', this.community_name);
        params.append('house_type', this.house_type);
        if(this.house_floor!='')
        params.append('house_floor', this.house_floor);
        else
        params.append('house_floor', -1);
        params.append('is_elevator', this.is_elevator);
        params.append('description', this.description);
        if(this.deposit!='')
        params.append('deposit', this.deposit);
        else
        params.append('deposit', -1);
        params.append('payment_method', this.payment_method);
        if(this.rent_per_month!='')
        params.append('rent_per_month', this.rent_per_month);
        else
        params.append('rent_per_month', -1);
				params.append('register_time', this.$options.methods.getNowFormatDate());
				params.append('modify_time', this.$options.methods.getNowFormatDate());
					this.$axios({                
						method:"post",                           
					url:'http://localhost:8080/RentHouseSystem/rent/AddRent',               
					 data:params,                            
					 }).then(res=> {
						let resultjson=res.data;
						console.log(resultjson);
						if (resultjson!=0) {
              this.house_id=resultjson;

              this.$message({message: '发布成功！',type: 'success'});
              console.log(this.house_id);
               
							
						}else{
							//this.$message({message: '注册失败！',type: 'success'});
							this.$message.error('注册失败,网络异常！');
							//window.alert('注册失败,服务器错误,请重试！');
						}
          })

			},       
      }
    }
  </script>