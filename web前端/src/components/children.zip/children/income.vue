<template>
  <el-col >
      <div>
        <router-link to = "/"><el-button><i class="el-icon-caret-left"></i> </el-button></router-link>
      </div>
      <div>
           <el-table
    :data="tableData"
    style="width: 100%"
    max-height="700">
    <el-table-column
      label="月度"
      align="left">
      <template slot-scope="scope">
        <i class="el-icon-time"></i>
        <span style="margin-left: 10px">{{ scope.row.gameid}}</span>
      </template>
    </el-table-column>
    <el-table-column
      label="地域"
      align="left">
      <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.status }}</span>
      </template>
    </el-table-column>
    <el-table-column
      label="成交笔数"
      align="left">
      <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.status }}</span>
      </template>
    </el-table-column>
    <el-table-column label="中介费" align="left">
      <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.home }}</span>
      </template>
    </el-table-column>
    <el-table-column label="收入金额" align="left">
        <template slot-scope="scope">
      <span style="margin-left: 10px">{{ scope.row.away }}</span>
      </template>
        </el-table-column>
  </el-table>
 <el-select v-model="value" placeholder="选择查看数据">
    <el-option
      v-for="item in option"
      :key="item.value"
      :label="item.label"
      :value="item.value">
    </el-option>
  </el-select>
    <div id="app" v-if="value == '1'">
        <schart :canvasId="canvasId"
            :type="type"
            :width="width"
            :height="height"
            :data="data"
            :options="options"
        ></schart>
    </div>
        <div id="app" v-if="value == '2'">
        <schart :canvasId="canvasId"
            :type="type"
            :width="width"
            :height="height"
            :data="data2"
            :options="options2"
        ></schart>
    </div>
      </div>
  </el-col>
</template>
<script>
import Schart from 'vue-schart';
export default {
    data() {
        return {
                     option: [{
          value: '1',
          label: '成交金额'
        }, {
          value: '2',
          label: '成交单数'
        }],
                value:'',
            canvasId: 'myCanvas',
            type: 'line',
            width: 500,
            height: 400,
            data: [
                {name: '2014', value: 1342},
                {name: '2015', value: 2123},
                {name: '2016', value: 1654},
                {name: '2017', value: 1795},
            ],
                  data2: [
                {name: '2014', value: 1},
                {name: '2015', value: 2},
                {name: '2016', value: 3},
                {name: '2017', value: 4},
            ],
            options: {
                title: 'Total sales of stores in recent years'
            },
            options2: {
                title: 'Total sales of stores in recent years'
            }
        }
    },
    components:{
        Schart
    }
}
</script>